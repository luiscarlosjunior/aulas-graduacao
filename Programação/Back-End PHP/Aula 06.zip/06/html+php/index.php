<!DOCTYPE html>
<html>
    <head>
        <title>
            Meu primeiro HTML
        </title>
    </head>
    <body>
        <h1> 
            <?php echo "Hello, world"; ?>
        </h1>
        <p> Este é um paragrafo </p>
    </body>
</html>