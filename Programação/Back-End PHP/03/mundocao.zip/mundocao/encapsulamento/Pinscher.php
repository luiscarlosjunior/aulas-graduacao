<?php

    class Pinscher extends Cachorro {
        public function tremer() {
            print("Estou tremendo..." . PHP_EOL);
        }
    }

?>