<?php

    class Poddle extends Cachorro {
        public function Brincar() {
            print("Estou brincando..." . PHP_EOL);
        }
    }

?>