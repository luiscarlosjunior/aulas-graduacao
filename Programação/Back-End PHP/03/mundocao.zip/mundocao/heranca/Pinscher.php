<?php

    class Pinscher extends Cachorro {
        public function Latir() {
            print("Estou tremendo..." . PHP_EOL);
        }
    }

?>