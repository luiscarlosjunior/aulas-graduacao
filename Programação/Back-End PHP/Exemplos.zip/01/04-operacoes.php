<?php

$soma = 2 + 2;
$subtracao = 2 - 2;
$multiplicacao = 2 * 2;
$divisao = 2 / 2;

$doisAoCubo = 2 ** 3;

$restoDaDivisao = 10 % 3;

echo $restoDaDivisao;
