<?php

$idade = 22;

$idade = 21;

echo $idade;
