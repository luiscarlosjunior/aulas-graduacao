<?php

$multiplicador = 3;

for ($i = 1; $i <= 100; $i++) {
    echo "$multiplicador x $i = " . $multiplicador * $i . PHP_EOL; 
}
