<?php

    class Lobo extends Animal {
        
        public function Som() {
            echo "Auuuuuuuuu!" . PHP_EOL;
        }

    }

?>