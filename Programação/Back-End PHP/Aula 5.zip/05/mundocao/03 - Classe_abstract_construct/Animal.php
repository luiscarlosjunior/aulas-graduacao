<?php

    abstract class Animal {
        protected string $especie;
        protected string $numeroPatas;
                
        public abstract function Som();

    }

?>