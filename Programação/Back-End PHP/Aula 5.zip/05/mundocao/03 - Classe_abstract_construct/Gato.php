<?php

    class Gato extends Animal {
        protected string $nome;
                
        public function Som()
        {
            echo "Miiiaaauuuuuu!" . PHP_EOL;
        }

    }

?>