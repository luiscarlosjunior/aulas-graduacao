<?php

    class Poddle extends Cachorro {
        public function brincar() {
            print("Estou brincando..." . PHP_EOL);
        }
    }

?>