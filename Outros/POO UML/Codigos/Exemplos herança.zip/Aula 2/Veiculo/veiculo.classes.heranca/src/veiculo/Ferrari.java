package veiculo;

public class Ferrari extends Veiculo {
	
}
