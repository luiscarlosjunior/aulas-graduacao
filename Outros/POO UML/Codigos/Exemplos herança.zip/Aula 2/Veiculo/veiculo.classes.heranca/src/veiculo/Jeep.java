package veiculo;

public class Jeep extends Veiculo {

}
