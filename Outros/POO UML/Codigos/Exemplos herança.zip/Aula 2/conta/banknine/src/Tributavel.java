
public interface Tributavel {

	double getValorImposto();
}
