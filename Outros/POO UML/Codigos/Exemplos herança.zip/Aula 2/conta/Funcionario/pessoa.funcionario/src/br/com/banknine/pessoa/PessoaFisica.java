package br.com.banknine.pessoa;

class PessoaFisica extends Pessoa {

	public String rg;

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}
	
}
