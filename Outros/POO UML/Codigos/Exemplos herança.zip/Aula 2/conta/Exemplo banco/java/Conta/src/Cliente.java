public class Cliente {
    
    public String CPF;
    public String Nome;
    public String Telefone;
    public String Endereco;

    public String MostrarCPF()
    {
        return "";
    }

    public void VerSaldo(int senha)
    {

    }

}
