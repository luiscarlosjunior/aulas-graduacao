
public class Conta {
	
	public int agencia;
	public String numeroConta;
	
	public void Depositar(float quantidade)
	{

	}

	public float Saldo(int Senha)
	{
		return 0.0f;
	}
	
}
