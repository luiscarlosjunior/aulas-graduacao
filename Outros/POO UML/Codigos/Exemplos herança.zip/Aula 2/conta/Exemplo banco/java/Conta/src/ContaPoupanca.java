public class ContaPoupanca extends Conta {
    
    public int DiaDeposito;

    public float VerLucro()
    {
        return 0;
    }

}
