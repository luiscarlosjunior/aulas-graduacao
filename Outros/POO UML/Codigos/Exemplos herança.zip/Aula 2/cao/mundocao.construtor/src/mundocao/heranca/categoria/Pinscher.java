package mundocao.heranca.categoria;

public class Pinscher extends Cachorro {

	public void Tremer()
	{
		System.out.println("Estou tremendo");
	}
}
