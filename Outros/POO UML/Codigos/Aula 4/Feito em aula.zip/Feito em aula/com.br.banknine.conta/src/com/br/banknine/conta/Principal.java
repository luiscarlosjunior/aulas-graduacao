package com.br.banknine.conta;

public class Principal {

	public static void main(String[] args) {
		
		ContaPoupanca luis = new ContaPoupanca();
		ContaPoupanca lais = new ContaPoupanca();
		ContaPoupanca roberta = new ContaPoupanca();
		
		luis.setAgencia(01);
		luis.setDiaDeposito(5);
		luis.setNumeroConta("002");
		
		lais.setAgencia(01);
		lais.setDiaDeposito(20);
		lais.setNumeroConta("003");
		
		roberta.setAgencia(01);
		roberta.setDiaDeposito(15);
		roberta.setNumeroConta("004");
		
		System.out.println("Minha conta � " + luis.getNumeroConta());
		System.out.println("Minha conta � " + lais.getNumeroConta());
		System.out.println("Minha conta � " + roberta.getNumeroConta());
		
	}

}
