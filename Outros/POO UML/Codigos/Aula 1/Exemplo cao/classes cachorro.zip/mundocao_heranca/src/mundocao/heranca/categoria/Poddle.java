
package mundocao.heranca.categoria;

public class Poddle extends Cachorro {
	// implementa todas os atributos e m�todos da superclasse Cachorro
	
	// Aqui iremos implementar somente um comportamento que os diferenciam
	public void Brincar()
	{
		System.out.println("Estou brincando");
	}
}
