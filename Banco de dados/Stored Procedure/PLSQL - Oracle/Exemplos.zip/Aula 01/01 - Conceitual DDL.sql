/*
	Esse arquivo tem como finalidade exemplificar atrav�s de exemplos a utiliza�ao
	de DDL
*/

/*
Comandos DDL

Create 
	Database NomeDB	
	Table NomeTabela
Alter 
	Database NomeDB	
	Table NomeTabela (
		ADD nomeCampo TIPO
		DROP column nomeCampo
	)
DROP
	Database NomeDB	
	Table NomeTabela
*/