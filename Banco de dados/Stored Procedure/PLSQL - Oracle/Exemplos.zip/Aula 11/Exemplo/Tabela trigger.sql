SELECT * FROM user_triggers;

-- Estrutura
/*
trigger_name: nome
trigger_type: tempo e tipo
triggering_event: evento que dispara
table_owner: propriet[ario da tabela associada
table_name: nome da tabela associada
status: ativo ou inativo
description: declara��o
trigger_body: bloco PL/SQL
*/