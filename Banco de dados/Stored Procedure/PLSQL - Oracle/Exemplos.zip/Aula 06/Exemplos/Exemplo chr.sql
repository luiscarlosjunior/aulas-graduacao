SET SERVEROUTPUT ON

DECLARE

BEGIN
  dbms_output.put_line(chr(65) || chr(78) || chr(65) || chr(46));
END;