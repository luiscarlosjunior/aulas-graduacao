-- podemos usar o insert
DECLARE 
  V_RA CHAR(9) := '55798993528';
  V_NOME VARCHAR2(50) := 'Daniela Dorneles';
BEGIN

END;
/