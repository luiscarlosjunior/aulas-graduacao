-- Primeira forma
execute helloworld;

--Segunda forma
exec helloworld;

-- Usando um bloco an�nimo
BEGIN
  helloworld;
END;

