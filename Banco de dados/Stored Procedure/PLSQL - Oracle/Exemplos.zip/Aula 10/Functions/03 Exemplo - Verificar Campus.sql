--Na declara��o de uma fun��o ou procedure, 
--n�o se deve restringir os par�metros de CHAR ou VARCHAR2 
--com um comprimento e os par�metros de um NUMBER com uma precis�o ou escala.

SET SERVEROUTPUT ON;

CREATE OR REPLACE FUNCTION VERIFICAR_CAMPUS (
 P_SIGLA IN CHAR)
 RETURN VARCHAR2 IS
 V_CAMPUS VARCHAR2(15);
BEGIN
 IF P_SIGLA = 'MM' THEN
  RETURN 'MEMORIAL';
 ELSIF P_SIGLA = 'VM' THEN
  RETURN 'VILA MARIA';
 ELSIF P_SIGLA = 'VG' THEN
  RETURN 'VERGUEIRO';
 ELSE
  RETURN 'SANTO AMARO';
 END IF;
END VERIFICAR_CAMPUS;
/
SELECT VERIFICAR_CAMPUS('VG') FROM DUAL;